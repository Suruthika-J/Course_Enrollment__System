package com.example.course_management_system2.controller;

import com.example.course_management_system2.model.Student;
import com.example.course_management_system2.service.StudentService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students")
@CrossOrigin
public class StudentController {
    @Autowired
    private StudentService studentService;

    @PostMapping("/register")
    public Student register(@RequestBody Student student) {
        return studentService.registerStudent(student);
    }

    @PostMapping("/login")
    public Student login(@RequestParam String username, 
                        @RequestParam String password) {
        return studentService.login(username, password);
    }
}