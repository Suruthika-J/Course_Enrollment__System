package com.example.course_management_system2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.example.course_management_system2.model")  // Ensure entities are scanned
@EnableJpaRepositories(basePackages = "com.example.course_management_system2.repository")  // Ensure repositories are scanned
@ComponentScan(basePackages = "com.example.course_management_system2") // Ensure services/controllers are scanned
public class CourseManagementSystem2Application {

    public static void main(String[] args) {
        SpringApplication.run(CourseManagementSystem2Application.class, args);
    }
}
