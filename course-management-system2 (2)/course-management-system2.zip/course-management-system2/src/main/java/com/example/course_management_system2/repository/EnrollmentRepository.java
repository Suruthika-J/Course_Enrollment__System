package com.example.course_management_system2.repository;

import com.example.course_management_system2.model.Enrollment;

import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentId(Long studentId);
    boolean existsByStudentIdAndCourseId(Long studentId, Long courseId);
}