package com.example.course_management_system2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagementSystem2ApplicationTests {

    @Test
    void contextLoads() {
        // Test to ensure the Spring Boot application context loads successfully
    }
}
